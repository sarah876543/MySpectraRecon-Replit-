import { Zone } from "@shared/schema";
import { X } from "lucide-react";
import { Button } from "@/components/ui/button";

interface ZoneOverlayProps {
  zones: Zone[];
  containerWidth: number;
  containerHeight: number;
  onRemoveZone: (zoneId: string) => void;
}

export function ZoneOverlay({
  zones,
  containerWidth,
  containerHeight,
  onRemoveZone,
}: ZoneOverlayProps) {
  if (containerWidth === 0 || containerHeight === 0) return null;

  return (
    <div className="absolute inset-0 pointer-events-none">
      {zones.map((zone) => {
        const left = (zone.x / 100) * containerWidth;
        const top = (zone.y / 100) * containerHeight;
        const width = (zone.width / 100) * containerWidth;
        const height = (zone.height / 100) * containerHeight;

        return (
          <div
            key={zone.id}
            className="absolute border-2 border-yellow-400/60 bg-yellow-400/5"
            style={{
              left: `${left}px`,
              top: `${top}px`,
              width: `${width}px`,
              height: `${height}px`,
              borderStyle: "dashed",
            }}
            data-testid={`zone-${zone.id}`}
          >
            {/* Zone label */}
            <div className="absolute -top-7 left-0 bg-black/90 border border-yellow-400/60 px-2 py-1 rounded text-xs font-mono pointer-events-auto">
              <div className="flex items-center gap-2">
                <span className="text-yellow-400 uppercase tracking-wide">
                  {zone.name}
                </span>
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-4 w-4 p-0 hover:bg-red-500/20"
                  onClick={() => onRemoveZone(zone.id)}
                  data-testid={`button-remove-zone-${zone.id}`}
                >
                  <X className="w-3 h-3 text-red-400" />
                </Button>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
