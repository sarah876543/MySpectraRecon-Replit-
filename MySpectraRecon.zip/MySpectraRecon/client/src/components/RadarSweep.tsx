import { motion } from "framer-motion";

export function RadarSweep() {
  return (
    <div className="relative w-32 h-32 opacity-40">
      {/* Concentric rings */}
      <div className="absolute inset-0 rounded-full border border-primary/30"></div>
      <div className="absolute inset-4 rounded-full border border-primary/20"></div>
      <div className="absolute inset-8 rounded-full border border-primary/10"></div>
      
      {/* Center dot */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-2 h-2 bg-primary rounded-full"></div>
      
      {/* Rotating sweep line */}
      <motion.div
        className="absolute top-1/2 left-1/2 origin-left h-0.5 bg-gradient-to-r from-primary/80 to-transparent"
        style={{ width: "50%" }}
        animate={{ rotate: 360 }}
        transition={{
          duration: 4,
          repeat: Infinity,
          ease: "linear",
        }}
      />
    </div>
  );
}
