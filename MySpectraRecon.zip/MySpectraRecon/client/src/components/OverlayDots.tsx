import { Hotspot } from "@shared/schema";
import { MoveRight } from "lucide-react";
import { motion } from "framer-motion";

interface OverlayDotsProps {
  hotspots: Hotspot[];
  containerWidth: number;
  containerHeight: number;
}

export function OverlayDots({ hotspots, containerWidth, containerHeight }: OverlayDotsProps) {
  if (containerWidth === 0 || containerHeight === 0) return null;

  return (
    <div className="absolute inset-0 pointer-events-none">
      {hotspots.map((hotspot) => {
        const left = (hotspot.x / 100) * containerWidth;
        const top = (hotspot.y / 100) * containerHeight;

        return (
          <div
            key={hotspot.id}
            className="absolute"
            style={{
              left: `${left}px`,
              top: `${top}px`,
              transform: "translate(-50%, -50%)",
            }}
          >
            {/* Pulsing dot */}
            <motion.div
              className="w-3 h-3 bg-primary rounded-full shadow-lg shadow-primary/50"
              animate={{
                scale: [1, 1.4, 1],
                opacity: [1, 0.6, 1],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                ease: "easeInOut",
              }}
            />

            {/* Connecting line */}
            <svg
              className="absolute top-0 left-0"
              style={{
                width: "80px",
                height: "60px",
                transform: "translate(6px, 6px)",
              }}
            >
              <line
                x1="0"
                y1="0"
                x2="75"
                y2="0"
                stroke="rgb(var(--primary) / 0.6)"
                strokeWidth="1"
                strokeDasharray="2,2"
              />
              <line
                x1="75"
                y1="0"
                x2="75"
                y2="-20"
                stroke="rgb(var(--primary) / 0.6)"
                strokeWidth="1"
                strokeDasharray="2,2"
              />
            </svg>

            {/* ID Badge */}
            <div
              className="absolute bg-black/90 border-l-2 border-primary px-2 py-1 rounded text-xs font-mono whitespace-nowrap"
              style={{
                left: "85px",
                top: "-26px",
              }}
              data-testid={`hotspot-badge-${hotspot.id}`}
            >
              <div className="flex items-center gap-2">
                <span className="text-primary font-bold">#{hotspot.id}</span>
                <span className="text-slate-400">|</span>
                <span className="text-foreground">
                  {(hotspot.confidence * 100).toFixed(0)}%
                </span>
                {hotspot.moving && (
                  <>
                    <span className="text-slate-400">|</span>
                    <MoveRight className="w-3 h-3 text-amber-400" />
                  </>
                )}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
