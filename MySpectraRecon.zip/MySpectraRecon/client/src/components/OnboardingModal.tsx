import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Camera, Crosshair, Download, Settings } from "lucide-react";

interface OnboardingModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function OnboardingModal({ isOpen, onClose }: OnboardingModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl" data-testid="dialog-onboarding" aria-describedby="onboarding-description">
        <DialogHeader>
          <DialogTitle className="text-2xl uppercase tracking-wide">
            Welcome to SpectraRecon
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6" id="onboarding-description">
          <p className="text-muted-foreground">
            A tactical thermal surveillance dashboard for real-time hotspot detection and motion
            tracking. This system is designed for military and rescue operation demonstrations.
          </p>

          <div className="grid md:grid-cols-2 gap-4">
            <FeatureCard
              icon={<Camera className="w-6 h-6 text-primary" />}
              title="Live & Demo Modes"
              description="Use your webcam for live thermal simulation or load demo videos for presentations"
            />
            <FeatureCard
              icon={<Crosshair className="w-6 h-6 text-primary" />}
              title="Hotspot Detection"
              description="Real-time detection with confidence scores, motion tracking, and customizable thresholds"
            />
            <FeatureCard
              icon={<Settings className="w-6 h-6 text-primary" />}
              title="Zone Monitoring"
              description="Draw zones on the feed to trigger alerts when targets are detected in specific areas"
            />
            <FeatureCard
              icon={<Download className="w-6 h-6 text-primary" />}
              title="Export Reports"
              description="Capture snapshots and export detection data in JSON and CSV formats"
            />
          </div>

          <div className="bg-amber-400/10 border border-amber-400/50 rounded-lg p-4">
            <h4 className="font-semibold text-amber-400 mb-2">Camera Permissions</h4>
            <p className="text-sm text-muted-foreground">
              When prompted, please allow camera access to use Live Feed mode. You can always use
              Demo Video mode without camera permissions.
            </p>
          </div>

          <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4">
            <h4 className="font-semibold mb-2">Quick Start Guide</h4>
            <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
              <li>Select Live Feed or Demo Video mode</li>
              <li>Toggle between Normal and Thermal view</li>
              <li>Adjust detection threshold and settings as needed</li>
              <li>Click "Start Detection" to begin scanning</li>
              <li>Capture snapshots and export reports for analysis</li>
            </ol>
          </div>

          <Button className="w-full" onClick={onClose} data-testid="button-close-onboarding">
            Get Started
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

interface FeatureCardProps {
  icon: React.ReactNode;
  title: string;
  description: string;
}

function FeatureCard({ icon, title, description }: FeatureCardProps) {
  return (
    <div className="bg-slate-900/50 border border-slate-700 rounded-lg p-4">
      <div className="flex items-start gap-3">
        <div className="mt-1">{icon}</div>
        <div>
          <h4 className="font-semibold mb-1">{title}</h4>
          <p className="text-xs text-muted-foreground">{description}</p>
        </div>
      </div>
    </div>
  );
}
