interface HUDMetricsProps {
  fps: number;
  targetCount: number;
  avgConfidence: number;
  lastScan: string;
  processingTime: number;
}

export function HUDMetrics({
  fps,
  targetCount,
  avgConfidence,
  lastScan,
  processingTime,
}: HUDMetricsProps) {
  return (
    <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
      <MetricCard label="FPS" value={fps.toFixed(1)} unit="" />
      <MetricCard label="TARGETS" value={targetCount.toString()} unit="" highlight />
      <MetricCard label="CONF" value={(avgConfidence * 100).toFixed(0)} unit="%" />
      <MetricCard label="PROC" value={processingTime.toFixed(0)} unit="ms" />
      <MetricCard label="SCAN" value={lastScan} unit="" small />
    </div>
  );
}

interface MetricCardProps {
  label: string;
  value: string;
  unit: string;
  highlight?: boolean;
  small?: boolean;
}

function MetricCard({ label, value, unit, highlight, small }: MetricCardProps) {
  return (
    <div className="bg-slate-900/90 border border-slate-700/50 rounded-md p-3">
      <div className="text-xs uppercase tracking-wider text-slate-500 mb-1 font-semibold">
        {label}
      </div>
      <div className={`font-mono font-bold ${small ? "text-lg" : "text-2xl"} ${highlight ? "text-primary" : "text-foreground"}`}>
        {value}
        {unit && <span className="text-sm ml-1 text-muted-foreground">{unit}</span>}
      </div>
    </div>
  );
}
