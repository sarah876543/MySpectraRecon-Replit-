import { useRef, useEffect, useState, useCallback } from "react";
import Webcam from "react-webcam";
import { Hotspot, DetectionSettings } from "@shared/schema";
import { detectHotspots, applyThermalColorMap, resetMotionDetection } from "@/lib/thermalUtils";
import { OverlayDots } from "./OverlayDots";
import { ZoneOverlay } from "./ZoneOverlay";
import { Zone } from "@shared/schema";
import { AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface ThermalWebcamProps {
  isRunning: boolean;
  isThermalMode: boolean;
  settings: DetectionSettings;
  zones: Zone[];
  onHotspotsDetected: (hotspots: Hotspot[]) => void;
  onFpsUpdate: (fps: number) => void;
  onProcessingTimeUpdate: (time: number) => void;
  onRemoveZone: (zoneId: string) => void;
  onZoneAlert: (zoneName: string, hotspotCount: number) => void;
}

export function ThermalWebcam({
  isRunning,
  isThermalMode,
  settings,
  zones,
  onHotspotsDetected,
  onFpsUpdate,
  onProcessingTimeUpdate,
  onRemoveZone,
  onZoneAlert,
}: ThermalWebcamProps) {
  const webcamRef = useRef<Webcam>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const thermalCanvasRef = useRef<HTMLCanvasElement>(null);
  const processingCanvasRef = useRef<HTMLCanvasElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });
  const [hasPermission, setHasPermission] = useState<boolean | null>(null);
  const [currentHotspots, setCurrentHotspots] = useState<Hotspot[]>([]);
  const [zoneAlerts, setZoneAlerts] = useState<Array<{ zoneName: string; count: number }>>([]);
  const frameCountRef = useRef(0);
  const lastFpsTimeRef = useRef(Date.now());

  const containerRef = useRef<HTMLDivElement>(null);

  // Update dimensions on mount and resize
  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.offsetWidth,
          height: containerRef.current.offsetHeight,
        });
      }
    };

    updateDimensions();
    window.addEventListener("resize", updateDimensions);
    return () => window.removeEventListener("resize", updateDimensions);
  }, []);

  // Reset motion detection when settings change
  useEffect(() => {
    resetMotionDetection();
  }, [settings]);

  const processFrame = useCallback(() => {
    if (!isRunning || !webcamRef.current || !canvasRef.current) return;

    const video = webcamRef.current.video;
    if (!video || video.readyState !== video.HAVE_ENOUGH_DATA) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) return;

    // Set canvas size to match video
    if (canvas.width !== video.videoWidth || canvas.height !== video.videoHeight) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      if (thermalCanvasRef.current) {
        thermalCanvasRef.current.width = video.videoWidth;
        thermalCanvasRef.current.height = video.videoHeight;
      }
    }

    // Draw current frame
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height);

    // Apply thermal color map if enabled
    if (isThermalMode && thermalCanvasRef.current) {
      applyThermalColorMap(canvas, thermalCanvasRef.current);
    }

    // Process frame for detection using downscaled version
    if (processingCanvasRef.current) {
      const procCanvas = processingCanvasRef.current;
      procCanvas.width = settings.downscale;
      procCanvas.height = Math.floor((settings.downscale * canvas.height) / canvas.width);
      
      const procCtx = procCanvas.getContext("2d", { willReadFrequently: true });
      if (procCtx) {
        procCtx.drawImage(canvas, 0, 0, procCanvas.width, procCanvas.height);
        const imageData = procCtx.getImageData(0, 0, procCanvas.width, procCanvas.height);
        
        const result = detectHotspots(imageData, settings);
        setCurrentHotspots(result.hotspots);
        onHotspotsDetected(result.hotspots);
        onProcessingTimeUpdate(result.processingTime);

        // Check zone alerts
        const newAlerts: Array<{ zoneName: string; count: number }> = [];
        zones.forEach((zone) => {
          const hotspotsInZone = result.hotspots.filter(
            (h) =>
              h.x >= zone.x &&
              h.x <= zone.x + zone.width &&
              h.y >= zone.y &&
              h.y <= zone.y + zone.height
          );
          if (hotspotsInZone.length > 0) {
            newAlerts.push({ zoneName: zone.name, count: hotspotsInZone.length });
            onZoneAlert(zone.name, hotspotsInZone.length);
          }
        });
        setZoneAlerts(newAlerts);
      }
    }

    // Update FPS
    frameCountRef.current++;
    const now = Date.now();
    if (now - lastFpsTimeRef.current >= 1000) {
      const fps = (frameCountRef.current * 1000) / (now - lastFpsTimeRef.current);
      onFpsUpdate(fps);
      frameCountRef.current = 0;
      lastFpsTimeRef.current = now;
    }
  }, [isRunning, isThermalMode, settings, zones, onHotspotsDetected, onFpsUpdate, onProcessingTimeUpdate, onZoneAlert]);

  // Processing loop
  useEffect(() => {
    if (!isRunning) return;

    const interval = setInterval(processFrame, 100); // ~10 FPS processing
    return () => clearInterval(interval);
  }, [isRunning, processFrame]);

  const handleUserMedia = () => {
    setHasPermission(true);
  };

  const handleUserMediaError = () => {
    setHasPermission(false);
  };

  return (
    <div ref={containerRef} className="relative w-full h-full bg-black rounded-lg overflow-hidden" data-testid="thermal-webcam-container">
      {/* Permission denied message */}
      {hasPermission === false && (
        <div className="absolute inset-0 flex items-center justify-center bg-slate-950 z-10">
          <div className="text-center p-8 max-w-md">
            <AlertTriangle className="w-16 h-16 text-amber-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2">Camera Access Denied</h3>
            <p className="text-sm text-muted-foreground">
              Please enable camera permissions in your browser settings to use live feed mode.
            </p>
          </div>
        </div>
      )}

      {/* Webcam */}
      <Webcam
        ref={webcamRef}
        audio={false}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ display: isThermalMode ? "none" : "block" }}
        onUserMedia={handleUserMedia}
        onUserMediaError={handleUserMediaError}
        screenshotFormat="image/png"
        videoConstraints={{
          facingMode: "user",
          width: { ideal: 1280 },
          height: { ideal: 720 },
        }}
      />

      {/* Thermal canvas (displayed when thermal mode is on) */}
      <canvas
        ref={thermalCanvasRef}
        className="absolute inset-0 w-full h-full object-cover"
        style={{ display: isThermalMode ? "block" : "none" }}
      />

      {/* Hidden canvases for processing */}
      <canvas ref={canvasRef} className="hidden" />
      <canvas ref={processingCanvasRef} className="hidden" />

      {/* Overlays */}
      {isRunning && (
        <>
          <OverlayDots
            hotspots={currentHotspots}
            containerWidth={dimensions.width}
            containerHeight={dimensions.height}
          />
          <ZoneOverlay
            zones={zones}
            containerWidth={dimensions.width}
            containerHeight={dimensions.height}
            onRemoveZone={onRemoveZone}
          />
        </>
      )}

      {/* Corner HUD */}
      <div className="absolute top-4 left-4 text-xs font-mono space-y-1">
        <div className="bg-black/80 px-2 py-1 rounded">
          <span className="text-slate-500">MODE:</span>{" "}
          <span className="text-primary">{isThermalMode ? "THERMAL" : "NORMAL"}</span>
        </div>
        <div className="bg-black/80 px-2 py-1 rounded">
          <span className="text-slate-500">TIME:</span>{" "}
          <span className="text-foreground">{new Date().toLocaleTimeString()}</span>
        </div>
      </div>

      {/* Zone alerts */}
      <div className="absolute top-4 right-4 space-y-2">
        <AnimatePresence>
          {zoneAlerts.map((alert, idx) => (
            <motion.div
              key={`${alert.zoneName}-${idx}`}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: 20 }}
              className="bg-yellow-400/20 border border-yellow-400 px-3 py-2 rounded text-xs font-mono"
            >
              <div className="flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-yellow-400" />
                <span className="text-yellow-400 font-semibold uppercase">
                  {alert.zoneName}: {alert.count} TARGET{alert.count !== 1 ? "S" : ""}
                </span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}
