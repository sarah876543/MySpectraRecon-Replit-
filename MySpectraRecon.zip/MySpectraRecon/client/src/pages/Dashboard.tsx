import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Hotspot, DetectionSettings, Snapshot, Zone, DetectionLog, InsertDeviceConfig } from "@shared/schema";
import { ThermalWebcam } from "@/components/ThermalWebcam";
import { ControlPanel } from "@/components/ControlPanel";
import { HUDMetrics } from "@/components/HUDMetrics";
import { RadarSweep } from "@/components/RadarSweep";
import { SnapshotsPanel } from "@/components/SnapshotsPanel";
import { LogsPanel } from "@/components/LogsPanel";
import { ZonesTool } from "@/components/ZonesTool";
import { DeviceSetup } from "@/components/DeviceSetup";
import { OnboardingModal } from "@/components/OnboardingModal";
import { Button } from "@/components/ui/button";
import { Settings, HelpCircle, Radio } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";

export default function Dashboard() {
  const { toast } = useToast();
  const [isRunning, setIsRunning] = useState(false);
  const [isThermalMode, setIsThermalMode] = useState(false);
  const [mode, setMode] = useState<"live" | "demo">("live");
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [showDeviceSetup, setShowDeviceSetup] = useState(false);

  const [settings, setSettings] = useState<DetectionSettings>({
    threshold: 128,
    cellSize: 16,
    downscale: 160,
    motionThreshold: 30,
    mergeDistance: 20,
  });

  const [currentHotspots, setCurrentHotspots] = useState<Hotspot[]>([]);
  const [fps, setFps] = useState(0);
  const [processingTime, setProcessingTime] = useState(0);
  const [lastScan, setLastScan] = useState("--:--");

  // Fetch data from backend using React Query
  const { data: snapshots = [], isLoading: snapshotsLoading } = useQuery<Snapshot[]>({
    queryKey: ["/api/snapshots"],
  });

  const { data: zones = [], isLoading: zonesLoading } = useQuery<Zone[]>({
    queryKey: ["/api/zones"],
  });

  const { data: logs = [], isLoading: logsLoading } = useQuery<DetectionLog[]>({
    queryKey: ["/api/logs"],
  });

  // Mutations for creating data
  const createSnapshotMutation = useMutation({
    mutationFn: async (snapshot: Omit<Snapshot, "id">) => {
      return apiRequest("POST", "/api/snapshots", snapshot);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/snapshots"] });
    },
  });

  const createZoneMutation = useMutation({
    mutationFn: async (zone: Omit<Zone, "id" | "createdAt">) => {
      return apiRequest("POST", "/api/zones", { ...zone, createdAt: new Date().toISOString() });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/zones"] });
    },
  });

  const deleteZoneMutation = useMutation({
    mutationFn: async (zoneId: string) => {
      return apiRequest("DELETE", `/api/zones/${zoneId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/zones"] });
    },
  });

  const updateZoneMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: string; updates: Partial<Zone> }) => {
      return apiRequest("PATCH", `/api/zones/${id}`, updates);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/zones"] });
    },
  });

  const createLogMutation = useMutation({
    mutationFn: async (log: Omit<DetectionLog, "id">) => {
      return apiRequest("POST", "/api/logs", log);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/logs"] });
    },
  });

  const deleteSnapshotMutation = useMutation({
    mutationFn: async (snapshotId: string) => {
      return apiRequest("DELETE", `/api/snapshots/${snapshotId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/snapshots"] });
    },
  });

  const createDeviceMutation = useMutation({
    mutationFn: async (device: InsertDeviceConfig) => {
      return apiRequest("POST", "/api/devices", device);
    },
  });

  // Update last scan time when hotspots are detected
  useEffect(() => {
    if (currentHotspots.length > 0) {
      setLastScan(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    }
  }, [currentHotspots]);

  const handleHotspotsDetected = (hotspots: Hotspot[]) => {
    setCurrentHotspots(hotspots);

    // Log detections to backend
    hotspots.forEach((hotspot) => {
      // Check if hotspot is in any zone
      const zone = zones.find(
        (z) =>
          z.enabled &&
          hotspot.x >= z.x &&
          hotspot.x <= z.x + z.width &&
          hotspot.y >= z.y &&
          hotspot.y <= z.y + z.height
      );

      const log: Omit<DetectionLog, "id"> = {
        hotspotId: hotspot.id,
        x: hotspot.x,
        y: hotspot.y,
        confidence: hotspot.confidence,
        intensity: hotspot.intensity,
        moving: hotspot.moving,
        zoneId: zone?.id,
        zoneName: zone?.name,
        timestamp: hotspot.timestamp,
      };

      createLogMutation.mutate(log);
    });
  };

  const handleSnapshot = async () => {
    // Create snapshot from current view
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Get the video element or thermal canvas
    const container = document.querySelector('[data-testid="thermal-webcam-container"]');
    const videoElement = container?.querySelector("video") || container?.querySelector("canvas");
    
    if (!videoElement) {
      toast({
        title: "Snapshot Failed",
        description: "No active feed to capture",
        variant: "destructive",
      });
      return;
    }

    // Set canvas size to match video
    if (videoElement instanceof HTMLVideoElement) {
      canvas.width = videoElement.videoWidth;
      canvas.height = videoElement.videoHeight;
      ctx.drawImage(videoElement, 0, 0);
    } else if (videoElement instanceof HTMLCanvasElement) {
      canvas.width = videoElement.width;
      canvas.height = videoElement.height;
      ctx.drawImage(videoElement, 0, 0);
    }

    const imageDataUrl = canvas.toDataURL("image/png");

    const snapshot: Omit<Snapshot, "id"> = {
      imageDataUrl,
      hotspots: currentHotspots,
      createdAt: new Date().toISOString(),
      mode: isThermalMode ? "thermal" : "normal",
    };

    createSnapshotMutation.mutate(snapshot, {
      onSuccess: () => {
        toast({
          title: "Snapshot Captured",
          description: `${currentHotspots.length} targets detected`,
        });
      },
      onError: () => {
        toast({
          title: "Snapshot Failed",
          description: "Failed to save snapshot to storage",
          variant: "destructive",
        });
      },
    });
  };

  const handleAddZone = (zoneData: Omit<Zone, "id" | "createdAt">) => {
    createZoneMutation.mutate(zoneData, {
      onSuccess: () => {
        toast({
          title: "Zone Added",
          description: `"${zoneData.name}" zone created`,
        });
      },
      onError: () => {
        toast({
          title: "Zone Creation Failed",
          description: "Failed to create detection zone",
          variant: "destructive",
        });
      },
    });
  };

  const handleRemoveZone = (zoneId: string) => {
    deleteZoneMutation.mutate(zoneId, {
      onSuccess: () => {
        toast({
          title: "Zone Removed",
          description: "Detection zone deleted",
        });
      },
      onError: () => {
        toast({
          title: "Delete Failed",
          description: "Failed to remove zone",
          variant: "destructive",
        });
      },
    });
  };

  const handleToggleZone = (zoneId: string) => {
    const zone = zones.find((z) => z.id === zoneId);
    if (!zone) return;

    updateZoneMutation.mutate({
      id: zoneId,
      updates: { enabled: !zone.enabled },
    });
  };

  const handleDeleteSnapshot = (snapshotId: string) => {
    deleteSnapshotMutation.mutate(snapshotId, {
      onSuccess: () => {
        toast({
          title: "Snapshot Deleted",
          description: "Snapshot removed from history",
        });
      },
      onError: () => {
        toast({
          title: "Delete Failed",
          description: "Failed to delete snapshot",
          variant: "destructive",
        });
      },
    });
  };

  const handleZoneAlert = (zoneName: string, hotspotCount: number) => {
    // Alert is shown visually in the feed overlay
  };

  const handleDeviceSetupComplete = (deviceType: string, connectionType: string) => {
    const deviceConfig: InsertDeviceConfig = {
      deviceType: deviceType as any,
      connectionType: connectionType as any,
      calibrated: true,
      connected: true,
      lastConnectedAt: new Date().toISOString(),
      createdAt: new Date().toISOString(),
    };

    createDeviceMutation.mutate(deviceConfig, {
      onSuccess: () => {
        toast({
          title: "Device Connected",
          description: `${deviceType} connected via ${connectionType}`,
        });
      },
    });
  };

  const avgConfidence =
    currentHotspots.length > 0
      ? currentHotspots.reduce((sum, h) => sum + h.confidence, 0) / currentHotspots.length
      : 0;

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Camouflage texture overlay */}
      <div
        className="fixed inset-0 opacity-5 pointer-events-none"
        style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='80' height='80'%3E%3Cpath d='M0 0h40v40H0zm40 40h40v40H40z' fill='%23000' fill-opacity='0.1'/%3E%3C/svg%3E")`,
          backgroundSize: "80px 80px",
        }}
      />

      {/* Header */}
      <header className="relative border-b border-slate-800 bg-slate-950/98 backdrop-blur-sm">
        <div className="container mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-xl font-bold uppercase tracking-widest text-foreground">
                  SpectraRecon
                </h1>
                <p className="text-xs text-slate-500 uppercase tracking-wide">
                  Tactical Surveillance System
                </p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <RadarSweep />
              <Link href="/live-tracking">
                <Button
                  variant="outline"
                  className="gap-2 border-[#00ff88] text-[#00ff88] hover:bg-[#00ff88] hover:text-slate-900"
                >
                  <Radio className="w-4 h-4" />
                  Live GPS Tracking
                </Button>
              </Link>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => setShowDeviceSetup(true)}
                data-testid="button-open-device-setup"
              >
                <Settings className="w-5 h-5" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                onClick={() => setShowOnboarding(true)}
                data-testid="button-open-help"
              >
                <HelpCircle className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-6 py-8">
        <div className="grid lg:grid-cols-[1fr,400px] gap-8">
          {/* Left Column - Feed & Metrics */}
          <div className="space-y-6">
            {/* HUD Metrics */}
            <HUDMetrics
              fps={fps}
              targetCount={currentHotspots.length}
              avgConfidence={avgConfidence}
              lastScan={lastScan}
              processingTime={processingTime}
            />

            {/* Thermal Feed */}
            <div className="aspect-video bg-black rounded-lg overflow-hidden border-2 border-slate-800">
              <ThermalWebcam
                isRunning={isRunning}
                isThermalMode={isThermalMode}
                settings={settings}
                zones={zones.filter((z) => z.enabled)}
                onHotspotsDetected={handleHotspotsDetected}
                onFpsUpdate={setFps}
                onProcessingTimeUpdate={setProcessingTime}
                onRemoveZone={handleRemoveZone}
                onZoneAlert={handleZoneAlert}
              />
            </div>
          </div>

          {/* Right Column - Controls & Data */}
          <div className="space-y-6">
            <ControlPanel
              isRunning={isRunning}
              isThermalMode={isThermalMode}
              mode={mode}
              settings={settings}
              onToggleRunning={() => setIsRunning(!isRunning)}
              onToggleThermalMode={() => setIsThermalMode(!isThermalMode)}
              onModeChange={setMode}
              onSettingsChange={setSettings}
              onSnapshot={handleSnapshot}
            />

            <Tabs defaultValue="zones" className="w-full">
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="zones" data-testid="tab-zones">
                  Zones
                </TabsTrigger>
                <TabsTrigger value="snapshots" data-testid="tab-snapshots">
                  Snapshots
                </TabsTrigger>
                <TabsTrigger value="logs" data-testid="tab-logs">
                  Logs
                </TabsTrigger>
              </TabsList>
              <TabsContent value="zones" className="mt-6">
                {zonesLoading ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Loading zones...
                  </div>
                ) : (
                  <ZonesTool
                    zones={zones}
                    onAddZone={handleAddZone}
                    onToggleZone={handleToggleZone}
                  />
                )}
              </TabsContent>
              <TabsContent value="snapshots" className="mt-6">
                {snapshotsLoading ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Loading snapshots...
                  </div>
                ) : (
                  <SnapshotsPanel
                    snapshots={snapshots}
                    onDeleteSnapshot={handleDeleteSnapshot}
                  />
                )}
              </TabsContent>
              <TabsContent value="logs" className="mt-6">
                {logsLoading ? (
                  <div className="text-center py-8 text-muted-foreground">
                    Loading logs...
                  </div>
                ) : (
                  <LogsPanel logs={logs} />
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>

      {/* Modals */}
      <OnboardingModal isOpen={showOnboarding} onClose={() => setShowOnboarding(false)} />
      <DeviceSetup
        isOpen={showDeviceSetup}
        onClose={() => setShowDeviceSetup(false)}
        onComplete={handleDeviceSetupComplete}
      />
    </div>
  );
}
