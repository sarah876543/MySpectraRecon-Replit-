import { useState, useEffect, useRef } from "react";
import { Link } from "wouter";
import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import { io, Socket } from "socket.io-client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { Navigation, Activity, Radio, MapPin, ArrowLeft } from "lucide-react";
import type { GpsLocation, MotionEvent, TrackedDevice } from "@shared/schema";
import "leaflet/dist/leaflet.css";
import L from "leaflet";

delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png",
  iconUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png",
  shadowUrl: "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png",
});

interface LocationHistory {
  [deviceId: string]: GpsLocation[];
}

export default function LiveTracking() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [isTracking, setIsTracking] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<GpsLocation | null>(null);
  const [allLocations, setAllLocations] = useState<LocationHistory>({});
  const [devices, setDevices] = useState<TrackedDevice[]>([]);
  const [motionEvents, setMotionEvents] = useState<MotionEvent[]>([]);
  const [deviceId, setDeviceId] = useState<string>("");
  const [trackedDeviceId, setTrackedDeviceId] = useState<string>("");
  const [error, setError] = useState<string>("");
  const [connected, setConnected] = useState(false);
  const [showMotionDetection, setShowMotionDetection] = useState(false);
  const watchIdRef = useRef<number | null>(null);

  useEffect(() => {
    const generatedId = `device-${Math.random().toString(36).substring(2, 9)}`;
    setDeviceId(generatedId);

    const newSocket = io(window.location.origin, {
      transports: ["websocket", "polling"],
    });

    newSocket.on("connect", () => {
      console.log("Connected to Socket.IO server");
      setConnected(true);
      setError("");
      
      newSocket.emit("device:register", {
        name: `Browser ${generatedId}`,
        type: "mobile",
        metadata: {
          userAgent: navigator.userAgent,
        },
      });
    });

    newSocket.on("disconnect", () => {
      console.log("Disconnected from Socket.IO server");
      setConnected(false);
    });

    newSocket.on("gps:location", (location: GpsLocation) => {
      setAllLocations((prev) => ({
        ...prev,
        [location.deviceId]: [...(prev[location.deviceId] || []), location].slice(-50),
      }));
    });

    newSocket.on("motion:alert", (event: MotionEvent) => {
      setMotionEvents((prev) => [event, ...prev].slice(0, 20));
    });

    newSocket.on("device:online", (device: TrackedDevice) => {
      setDevices((prev) => {
        const existing = prev.find((d) => d.id === device.id);
        if (existing) {
          return prev.map((d) => (d.id === device.id ? device : d));
        }
        return [...prev, device];
      });
    });

    newSocket.on("device:offline", (device: TrackedDevice) => {
      setDevices((prev) => {
        return prev.map((d) => (d.id === device.id ? device : d));
      });
    });

    newSocket.on("device:registered", (device: TrackedDevice) => {
      setTrackedDeviceId(device.id);
    });

    setSocket(newSocket);

    fetchDevices();

    return () => {
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
      }
      newSocket.disconnect();
    };
  }, []);

  const fetchDevices = async () => {
    try {
      const response = await fetch("/api/tracked-devices");
      if (response.ok) {
        const data = await response.json();
        setDevices(data);
      }
    } catch (err) {
      console.error("Failed to fetch devices:", err);
    }
  };

  const startTracking = () => {
    if (!navigator.geolocation) {
      setError("Geolocation is not supported by your browser");
      return;
    }

    setIsTracking(true);
    setError("");

    watchIdRef.current = navigator.geolocation.watchPosition(
      (position) => {
        const location: Omit<GpsLocation, "id"> & { trackedDeviceId?: string } = {
          deviceId,
          deviceName: `Browser ${deviceId.substring(0, 8)}`,
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          altitude: position.coords.altitude || undefined,
          heading: position.coords.heading || undefined,
          speed: position.coords.speed || undefined,
          timestamp: new Date().toISOString(),
          trackedDeviceId: trackedDeviceId || undefined,
        };

        setCurrentLocation(location as GpsLocation);

        if (socket?.connected) {
          socket.emit("gps:update", location);
        }
      },
      (error) => {
        setError(`GPS Error: ${error.message}`);
        setIsTracking(false);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  };

  const stopTracking = () => {
    if (watchIdRef.current !== null) {
      navigator.geolocation.clearWatch(watchIdRef.current);
      watchIdRef.current = null;
    }
    setIsTracking(false);
  };

  const startMotionDetection = () => {
    if (typeof DeviceMotionEvent !== "undefined" && typeof (DeviceMotionEvent as any).requestPermission === "function") {
      (DeviceMotionEvent as any).requestPermission()
        .then((permissionState: string) => {
          if (permissionState === "granted") {
            setupMotionListener();
          }
        })
        .catch(console.error);
    } else {
      setupMotionListener();
    }
  };

  const setupMotionListener = () => {
    setShowMotionDetection(true);
    
    window.addEventListener("devicemotion", (event) => {
      const acc = event.acceleration || event.accelerationIncludingGravity;
      const rot = event.rotationRate;

      if (acc) {
        const intensity = Math.sqrt(
          Math.pow(acc.x || 0, 2) + 
          Math.pow(acc.y || 0, 2) + 
          Math.pow(acc.z || 0, 2)
        );

        if (intensity > 5 && socket?.connected) {
          const motionEvent: Omit<MotionEvent, "id"> & { trackedDeviceId?: string } = {
            deviceId,
            deviceName: `Browser ${deviceId.substring(0, 8)}`,
            accelerationX: acc.x || undefined,
            accelerationY: acc.y || undefined,
            accelerationZ: acc.z || undefined,
            rotationAlpha: rot?.alpha || undefined,
            rotationBeta: rot?.beta || undefined,
            rotationGamma: rot?.gamma || undefined,
            motionIntensity: intensity,
            motionDetected: true,
            timestamp: new Date().toISOString(),
            trackedDeviceId: trackedDeviceId || undefined,
          };

          socket.emit("motion:detected", motionEvent);
        }
      }
    });
  };

  const defaultCenter: [number, number] = currentLocation 
    ? [currentLocation.latitude, currentLocation.longitude]
    : [37.7749, -122.4194];

  return (
    <div className="min-h-screen bg-slate-950 text-white p-4">
      <div className="max-w-7xl mx-auto">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <Button variant="ghost" className="gap-2">
                <ArrowLeft size={20} />
                Back to Dashboard
              </Button>
            </Link>
            <div>
              <h1 className="text-3xl font-bold font-['Rajdhani'] tracking-wide">
                LIVE GPS TRACKING
              </h1>
              <p className="text-slate-400 mt-1">Real-time device location monitoring</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Radio className={connected ? "text-green-400" : "text-red-400"} size={20} />
            <span className="text-sm">
              {connected ? "Connected" : "Disconnected"}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-['Rajdhani']">
                  <MapPin className="text-[#00ff88]" />
                  Live Map View
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-[500px] rounded-lg overflow-hidden border border-slate-700">
                  <MapContainer
                    center={defaultCenter}
                    zoom={13}
                    style={{ height: "100%", width: "100%" }}
                  >
                    <TileLayer
                      attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                      url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                    />
                    
                    {Object.entries(allLocations).map(([devId, locations]) => {
                      const latest = locations[locations.length - 1];
                      const path: [number, number][] = locations.map((loc) => [
                        loc.latitude,
                        loc.longitude,
                      ]);
                      
                      return (
                        <div key={devId}>
                          {path.length > 1 && (
                            <Polyline positions={path} color="#00ff88" weight={2} />
                          )}
                          {latest && (
                            <Marker position={[latest.latitude, latest.longitude]}>
                              <Popup>
                                <div className="text-slate-900">
                                  <strong>{latest.deviceName || latest.deviceId}</strong>
                                  <br />
                                  Lat: {latest.latitude.toFixed(6)}
                                  <br />
                                  Lng: {latest.longitude.toFixed(6)}
                                  <br />
                                  {latest.accuracy && `Accuracy: ${latest.accuracy.toFixed(0)}m`}
                                </div>
                              </Popup>
                            </Marker>
                          )}
                        </div>
                      );
                    })}
                  </MapContainer>
                </div>
              </CardContent>
            </Card>
          </div>

          <div className="space-y-4">
            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-['Rajdhani']">
                  <Navigation className="text-[#00ff88]" />
                  GPS Control
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                {error && (
                  <div className="p-3 bg-red-500/10 border border-red-500 rounded text-red-400 text-sm">
                    {error}
                  </div>
                )}
                
                <div className="space-y-2">
                  <Label>Device ID</Label>
                  <div className="p-2 bg-slate-800 rounded text-xs font-mono break-all">
                    {deviceId}
                  </div>
                </div>

                {currentLocation && (
                  <div className="space-y-2">
                    <Label>Current Position</Label>
                    <div className="text-sm space-y-1">
                      <div>Lat: <span className="text-[#00ff88]">{currentLocation.latitude.toFixed(6)}</span></div>
                      <div>Lng: <span className="text-[#00ff88]">{currentLocation.longitude.toFixed(6)}</span></div>
                      {currentLocation.accuracy && (
                        <div>Accuracy: <span className="text-[#00ff88]">{currentLocation.accuracy.toFixed(0)}m</span></div>
                      )}
                    </div>
                  </div>
                )}

                <Separator className="bg-slate-700" />

                <div className="space-y-2">
                  <Button
                    onClick={isTracking ? stopTracking : startTracking}
                    className={`w-full ${
                      isTracking
                        ? "bg-red-600 hover:bg-red-700"
                        : "bg-[#00ff88] text-slate-900 hover:bg-[#00dd77]"
                    }`}
                    disabled={!connected}
                  >
                    {isTracking ? "Stop Tracking" : "Start GPS Tracking"}
                  </Button>

                  <div className="flex items-center justify-between">
                    <Label htmlFor="motion-detection">Motion Detection</Label>
                    <Switch
                      id="motion-detection"
                      checked={showMotionDetection}
                      onCheckedChange={(checked) => {
                        if (checked) {
                          startMotionDetection();
                        } else {
                          setShowMotionDetection(false);
                        }
                      }}
                      disabled={!connected}
                    />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-slate-900 border-slate-700">
              <CardHeader>
                <CardTitle className="flex items-center gap-2 font-['Rajdhani']">
                  <Activity className="text-[#00ff88]" />
                  Active Devices ({devices.length})
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2 max-h-48 overflow-y-auto">
                  {devices.length === 0 ? (
                    <p className="text-slate-400 text-sm">No devices online</p>
                  ) : (
                    devices.map((device) => (
                      <div
                        key={device.id}
                        className="p-2 bg-slate-800 rounded flex items-center justify-between"
                      >
                        <div className="flex-1 min-w-0">
                          <div className="text-sm font-medium truncate">
                            {device.name}
                          </div>
                          <div className="text-xs text-slate-400 font-mono truncate">
                            {device.id.substring(0, 12)}...
                          </div>
                        </div>
                        <Badge
                          variant={device.status === "online" ? "default" : "secondary"}
                          className={device.status === "online" ? "bg-green-500" : ""}
                        >
                          {device.status}
                        </Badge>
                      </div>
                    ))
                  )}
                </div>
              </CardContent>
            </Card>

            {showMotionDetection && motionEvents.length > 0 && (
              <Card className="bg-slate-900 border-slate-700">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2 font-['Rajdhani']">
                    <Activity className="text-amber-400" />
                    Motion Alerts ({motionEvents.length})
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {motionEvents.map((event, idx) => (
                      <div
                        key={event.id || idx}
                        className="p-2 bg-slate-800 rounded text-sm"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-medium text-amber-400">
                            Motion Detected
                          </span>
                          <Badge variant="outline" className="text-xs">
                            {event.motionIntensity.toFixed(1)}
                          </Badge>
                        </div>
                        <div className="text-xs text-slate-400 mt-1">
                          {new Date(event.timestamp).toLocaleTimeString()}
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
