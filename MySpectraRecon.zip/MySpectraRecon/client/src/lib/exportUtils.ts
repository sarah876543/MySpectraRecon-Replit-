import { Snapshot, DetectionLog } from "@shared/schema";

export const downloadJSON = (data: any, filename: string): void => {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const downloadCSV = (data: any[], filename: string): void => {
  if (data.length === 0) {
    return;
  }

  const headers = Object.keys(data[0]);
  const csvRows = [
    headers.join(","),
    ...data.map((row) =>
      headers.map((header) => {
        const value = row[header];
        if (value === null || value === undefined) return "";
        if (typeof value === "string" && value.includes(",")) {
          return `"${value}"`;
        }
        return value;
      }).join(",")
    ),
  ];

  const csvContent = csvRows.join("\n");
  const blob = new Blob([csvContent], { type: "text/csv" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
};

export const downloadImage = (dataUrl: string, filename: string): void => {
  const a = document.createElement("a");
  a.href = dataUrl;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
};

export const exportSnapshot = (snapshot: Snapshot): void => {
  // Download image
  downloadImage(snapshot.imageDataUrl, `snapshot-${snapshot.id}.png`);
  
  // Download JSON
  downloadJSON(snapshot, `snapshot-${snapshot.id}.json`);
};

export const exportDetectionLogsCSV = (logs: DetectionLog[]): void => {
  const csvData = logs.map((log) => ({
    id: log.id,
    hotspotId: log.hotspotId,
    x: log.x.toFixed(2),
    y: log.y.toFixed(2),
    confidence: (log.confidence * 100).toFixed(1) + "%",
    intensity: log.intensity.toFixed(1),
    moving: log.moving ? "Yes" : "No",
    zone: log.zoneName || "N/A",
    timestamp: new Date(log.timestamp).toLocaleString(),
  }));

  downloadCSV(csvData, `detection-logs-${Date.now()}.csv`);
};
