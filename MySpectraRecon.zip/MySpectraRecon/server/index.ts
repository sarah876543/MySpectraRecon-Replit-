import express, { type Request, Response, NextFunction } from "express";
import { Server as SocketIOServer } from "socket.io";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage } from "./storage";
import { 
  insertGpsLocationSchema, 
  insertMotionEventSchema 
} from "@shared/schema";

const app = express();

declare module 'http' {
  interface IncomingMessage {
    rawBody: unknown
  }
}
app.use(express.json({
  verify: (req, _res, buf) => {
    req.rawBody = buf;
  }
}));
app.use(express.urlencoded({ extended: false }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // Set up Socket.IO for real-time GPS and motion tracking
  const io = new SocketIOServer(server, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const socketDeviceMap = new Map<string, string>();

  io.on("connection", (socket) => {
    log(`Socket.io client connected: ${socket.id}`, "websocket");

    socket.on("gps:update", async (data) => {
      try {
        const validated = insertGpsLocationSchema.parse(data);
        const location = await storage.createGpsLocation(validated);
        
        let trackedDeviceId = socketDeviceMap.get(socket.id);
        
        if (validated.trackedDeviceId && !trackedDeviceId) {
          trackedDeviceId = validated.trackedDeviceId;
          socketDeviceMap.set(socket.id, trackedDeviceId);
        }
        
        if (trackedDeviceId) {
          await storage.updateTrackedDevice(trackedDeviceId, {
            status: "online",
            lastSeen: new Date().toISOString()
          });
        } else {
          log(`GPS update without tracked device ID for ${validated.deviceId}`, "websocket");
        }
        
        io.emit("gps:location", location);
        log(`GPS update from ${validated.deviceId}`, "websocket");
      } catch (error) {
        log(`Invalid GPS data: ${error}`, "websocket");
      }
    });

    socket.on("motion:detected", async (data) => {
      try {
        const validated = insertMotionEventSchema.parse(data);
        const event = await storage.createMotionEvent(validated);
        
        let trackedDeviceId = socketDeviceMap.get(socket.id);
        
        if (validated.trackedDeviceId && !trackedDeviceId) {
          trackedDeviceId = validated.trackedDeviceId;
          socketDeviceMap.set(socket.id, trackedDeviceId);
        }
        
        if (trackedDeviceId) {
          await storage.updateTrackedDevice(trackedDeviceId, {
            status: "online",
            lastSeen: new Date().toISOString()
          });
        } else {
          log(`Motion detected without tracked device ID for ${validated.deviceId}`, "websocket");
        }
        
        io.emit("motion:alert", event);
        log(`Motion detected from ${validated.deviceId}`, "websocket");
      } catch (error) {
        log(`Invalid motion data: ${error}`, "websocket");
      }
    });

    socket.on("device:register", async (data) => {
      try {
        const device = await storage.createTrackedDevice({
          name: data.name || `Device ${socket.id.substring(0, 8)}`,
          type: data.type || "mobile",
          status: "online",
          lastSeen: new Date().toISOString(),
          createdAt: new Date().toISOString(),
          metadata: data.metadata
        });
        
        socketDeviceMap.set(socket.id, device.id);
        
        socket.emit("device:registered", device);
        io.emit("device:online", device);
        log(`Device registered: ${device.name}`, "websocket");
      } catch (error) {
        log(`Device registration failed: ${error}`, "websocket");
      }
    });

    socket.on("disconnect", async () => {
      const trackedDeviceId = socketDeviceMap.get(socket.id);
      
      if (trackedDeviceId) {
        try {
          const updatedDevice = await storage.updateTrackedDevice(trackedDeviceId, {
            status: "offline",
            lastSeen: new Date().toISOString()
          });
          
          if (updatedDevice) {
            io.emit("device:offline", updatedDevice);
            log(`Device offline: ${updatedDevice.name}`, "websocket");
          }
        } catch (error) {
          log(`Error updating device status on disconnect: ${error}`, "websocket");
        }
        
        socketDeviceMap.delete(socket.id);
      }
      
      log(`Socket.io client disconnected: ${socket.id}`, "websocket");
    });
  });

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
    log(`Socket.io ready for real-time tracking`, "websocket");
  });
})();
