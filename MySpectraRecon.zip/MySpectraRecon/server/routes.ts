import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import {
  insertSnapshotSchema,
  insertZoneSchema,
  insertDetectionLogSchema,
  insertDeviceConfigSchema,
  telemetryDataSchema,
  insertGpsLocationSchema,
  insertMotionEventSchema,
  insertTrackedDeviceSchema,
} from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Snapshots
  app.get("/api/snapshots", async (req, res) => {
    try {
      const snapshots = await storage.getSnapshots();
      res.json(snapshots);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch snapshots" });
    }
  });

  app.post("/api/snapshots", async (req, res) => {
    try {
      const data = insertSnapshotSchema.parse(req.body);
      const snapshot = await storage.createSnapshot(data);
      res.status(201).json(snapshot);
    } catch (error) {
      res.status(400).json({ error: "Invalid snapshot data" });
    }
  });

  app.delete("/api/snapshots/:id", async (req, res) => {
    try {
      const success = await storage.deleteSnapshot(req.params.id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ error: "Snapshot not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete snapshot" });
    }
  });

  // Zones
  app.get("/api/zones", async (req, res) => {
    try {
      const zones = await storage.getZones();
      res.json(zones);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch zones" });
    }
  });

  app.post("/api/zones", async (req, res) => {
    try {
      const data = insertZoneSchema.parse(req.body);
      const zone = await storage.createZone(data);
      res.status(201).json(zone);
    } catch (error) {
      res.status(400).json({ error: "Invalid zone data" });
    }
  });

  app.patch("/api/zones/:id", async (req, res) => {
    try {
      const zone = await storage.updateZone(req.params.id, req.body);
      if (zone) {
        res.json(zone);
      } else {
        res.status(404).json({ error: "Zone not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to update zone" });
    }
  });

  app.delete("/api/zones/:id", async (req, res) => {
    try {
      const success = await storage.deleteZone(req.params.id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ error: "Zone not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete zone" });
    }
  });

  // Detection Logs
  app.get("/api/logs", async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const logs = await storage.getDetectionLogs(limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch logs" });
    }
  });

  app.post("/api/logs", async (req, res) => {
    try {
      const data = insertDetectionLogSchema.parse(req.body);
      const log = await storage.createDetectionLog(data);
      res.status(201).json(log);
    } catch (error) {
      res.status(400).json({ error: "Invalid log data" });
    }
  });

  app.delete("/api/logs", async (req, res) => {
    try {
      await storage.clearDetectionLogs();
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to clear logs" });
    }
  });

  // Device Configurations
  app.get("/api/devices", async (req, res) => {
    try {
      const devices = await storage.getDeviceConfigs();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch devices" });
    }
  });

  app.post("/api/devices", async (req, res) => {
    try {
      const data = insertDeviceConfigSchema.parse(req.body);
      const device = await storage.createDeviceConfig(data);
      res.status(201).json(device);
    } catch (error) {
      res.status(400).json({ error: "Invalid device data" });
    }
  });

  app.patch("/api/devices/:id", async (req, res) => {
    try {
      const device = await storage.updateDeviceConfig(req.params.id, req.body);
      if (device) {
        res.json(device);
      } else {
        res.status(404).json({ error: "Device not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to update device" });
    }
  });

  // Telemetry (simulated sensor data)
  app.get("/api/telemetry", async (req, res) => {
    try {
      const telemetry = await storage.getLatestTelemetry();
      if (telemetry) {
        res.json(telemetry);
      } else {
        // Return mock telemetry if none exists
        const mockTelemetry = {
          deviceId: "simulated-sensor-1",
          temperature: 20 + Math.random() * 10,
          humidity: 40 + Math.random() * 20,
          fps: 10,
          processingTime: 30 + Math.random() * 20,
          hotspotCount: Math.floor(Math.random() * 5),
          timestamp: new Date().toISOString(),
        };
        res.json(mockTelemetry);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch telemetry" });
    }
  });

  app.post("/api/telemetry", async (req, res) => {
    try {
      const data = telemetryDataSchema.parse(req.body);
      await storage.storeTelemetry(data);
      res.status(201).json(data);
    } catch (error) {
      res.status(400).json({ error: "Invalid telemetry data" });
    }
  });

  // GPS Locations
  app.get("/api/locations", async (req, res) => {
    try {
      const deviceId = req.query.deviceId as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const locations = await storage.getGpsLocations(deviceId, limit);
      res.json(locations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch locations" });
    }
  });

  app.post("/api/locations", async (req, res) => {
    try {
      const data = insertGpsLocationSchema.parse(req.body);
      const location = await storage.createGpsLocation(data);
      res.status(201).json(location);
    } catch (error) {
      res.status(400).json({ error: "Invalid location data" });
    }
  });

  app.get("/api/locations/latest/:deviceId", async (req, res) => {
    try {
      const location = await storage.getLatestGpsLocation(req.params.deviceId);
      if (location) {
        res.json(location);
      } else {
        res.status(404).json({ error: "No location found for device" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch location" });
    }
  });

  // Motion Events
  app.get("/api/motion", async (req, res) => {
    try {
      const deviceId = req.query.deviceId as string | undefined;
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const events = await storage.getMotionEvents(deviceId, limit);
      res.json(events);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch motion events" });
    }
  });

  app.post("/api/motion", async (req, res) => {
    try {
      const data = insertMotionEventSchema.parse(req.body);
      const event = await storage.createMotionEvent(data);
      res.status(201).json(event);
    } catch (error) {
      res.status(400).json({ error: "Invalid motion data" });
    }
  });

  app.delete("/api/motion", async (req, res) => {
    try {
      await storage.clearMotionEvents();
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to clear motion events" });
    }
  });

  // Tracked Devices
  app.get("/api/tracked-devices", async (req, res) => {
    try {
      const devices = await storage.getTrackedDevices();
      res.json(devices);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch devices" });
    }
  });

  app.post("/api/tracked-devices", async (req, res) => {
    try {
      const data = insertTrackedDeviceSchema.parse(req.body);
      const device = await storage.createTrackedDevice(data);
      res.status(201).json(device);
    } catch (error) {
      res.status(400).json({ error: "Invalid device data" });
    }
  });

  app.get("/api/tracked-devices/:id", async (req, res) => {
    try {
      const device = await storage.getTrackedDevice(req.params.id);
      if (device) {
        res.json(device);
      } else {
        res.status(404).json({ error: "Device not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch device" });
    }
  });

  app.patch("/api/tracked-devices/:id", async (req, res) => {
    try {
      const device = await storage.updateTrackedDevice(req.params.id, req.body);
      if (device) {
        res.json(device);
      } else {
        res.status(404).json({ error: "Device not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to update device" });
    }
  });

  app.delete("/api/tracked-devices/:id", async (req, res) => {
    try {
      const success = await storage.deleteTrackedDevice(req.params.id);
      if (success) {
        res.status(204).send();
      } else {
        res.status(404).json({ error: "Device not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to delete device" });
    }
  });

  // Health check
  app.get("/api/health", (req, res) => {
    res.json({
      status: "operational",
      timestamp: new Date().toISOString(),
      service: "SpectraRecon Tactical Surveillance API",
    });
  });

  const httpServer = createServer(app);

  return httpServer;
}
